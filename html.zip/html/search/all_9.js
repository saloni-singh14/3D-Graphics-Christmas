var searchData=
[
  ['recreation_20of_20a_20peaceful_20christmas_20eve_46',['Recreation of a peaceful Christmas Eve',['../index.html',1,'']]],
  ['renderscene_47',['renderScene',['../_christmas_8cpp.html#a2a96aed746d13d9b42d7888e156045f6',1,'Christmas.cpp']]],
  ['roll_48',['roll',['../_christmas_8cpp.html#a26fd84d522945b6038221d9e38c7cc39',1,'Christmas.cpp']]],
  ['rollangle_49',['rollangle',['../_christmas_8cpp.html#a600373f25a7ef7688c5398fb9123737c',1,'Christmas.cpp']]]
];
