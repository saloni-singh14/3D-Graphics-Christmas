var searchData=
[
  ['halfheight_30',['halfHeight',['../_christmas_8cpp.html#aee825f094f2a85838f96dbadda5b4c44',1,'Christmas.cpp']]],
  ['halfwidth_31',['halfWidth',['../_christmas_8cpp.html#aa7f0235de7acde8ba613b4ee33f404be',1,'Christmas.cpp']]]
];
