var searchData=
[
  ['up_145',['Up',['../_setting.html',1,'']]]
];
