var searchData=
[
  ['window_5fheight_176',['WINDOW_HEIGHT',['../classroom_8cpp.html#a5473cf64fa979b48335079c99532e243',1,'classroom.cpp']]],
  ['window_5fwidth_177',['WINDOW_WIDTH',['../classroom_8cpp.html#a498d9f026138406895e9a34b504ac6a6',1,'classroom.cpp']]]
];
