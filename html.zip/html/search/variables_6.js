var searchData=
[
  ['roll_129',['roll',['../_christmas_8cpp.html#a26fd84d522945b6038221d9e38c7cc39',1,'Christmas.cpp']]],
  ['rollangle_130',['rollangle',['../_christmas_8cpp.html#a600373f25a7ef7688c5398fb9123737c',1,'Christmas.cpp']]]
];
