var searchData=
[
  ['angle_0',['angle',['../_christmas_8cpp.html#ab8ef1bf8a70cc07c6d55823c390a7e76',1,'Christmas.cpp']]],
  ['animate_1',['animate',['../_christmas_8cpp.html#a3e73164d603e05e94b8eedeb557a3245',1,'Christmas.cpp']]]
];
