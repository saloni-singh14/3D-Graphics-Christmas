var searchData=
[
  ['angle_116',['angle',['../_christmas_8cpp.html#ab8ef1bf8a70cc07c6d55823c390a7e76',1,'Christmas.cpp']]]
];
