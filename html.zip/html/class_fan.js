var class_fan =
[
    [ "drawFan", "class_fan.html#a84402d61fb1cf52b19713d1ec785fa48", null ],
    [ "rotateFan", "class_fan.html#a49d6c4fd92fbdb3700957c4d469617a7", null ]
];