var class_chair =
[
    [ "drawChair", "class_chair.html#a02b6b3b765378db38a7deb7aae506198", null ]
];