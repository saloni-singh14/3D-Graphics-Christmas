var annotated_dup =
[
    [ "Chair", "class_chair.html", "class_chair" ],
    [ "Snowman", "class_snowman.html", "class_snowman" ],
    [ "Table", "class_table.html", "class_table" ],
    [ "Window", "class_window.html", "class_window" ]
];